package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.example")
public class LibraryManagementApplication1 {

    public static void main(String[] args) {
        SpringApplication.run(LibraryManagementApplication1.class, args);
    }
}
